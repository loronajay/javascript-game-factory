# Mini-Tactics (Isometric Squad Tactics) — Claude Context

## What This Game Is
A turn-based isometric SVG squad-tactics game: two players, four pieces each
(warrior, tank, ranger, medic) on a 10×10 or 13×13 diamond board. Being converted
from a local-hot-seat prototype into a full platform cabinet.

Full design/conversion plan: `ISOMETRIC_SQUAD_TACTICS_AGENT_SCOPE.md` (6 milestones:
Cancel Move → deterministic core → screen flow → hot seat → CPU → online → packaging).
Rules reference: `README.md`. This file tracks the **as-built reality**, not the plan.

## Current Build Status

**Playable hot-seat game (2–4 players) on a deterministic, headless-testable core,
with a title→menu→setup→match→results screen flow. Not yet on the grid** — no
`game.json`, no `arcade-catalog.mjs` entry, no `grid-previews/mini-tactics.png`. No
CPU, no online yet.

- **Milestone 0+1 — done:** deterministic headless engine (`src/core/`) + Cancel Move.
- **Multiplayer up to 4 players (FFA + 2v2 teams) — core AND UI shipped:** the
  deterministic core supports 2P duel, 3–4P free-for-all, and 2v2 teams (see "Player
  Roster & Teams"), and the hot-seat setup screen, colors, and HUD now expose it. Default
  `createMatchState()` still produces the exact classic two-player duel, so the old
  hot-seat path is byte-for-byte unchanged.
- **Tests:** `tests/rules.test.js`, `tests/reducer.test.js`, `tests/determinism.test.js`,
  `tests/multiplayer.test.js` — **55/55 green** via `npm test` (`node --test`). No
  browser driver in repo; the user playtests visuals in the browser themselves. The UI
  layer (screens/renderers) is verified by `node --check` + headless logic smoke only.
- **Next milestones, in order:** hot seat polish → CPU → online → packaging.

**Locked online decision (2026-06-21):** Online will be **host-authoritative over
the existing relay** (`factory-network-server`), NOT true server-authoritative. The
scope doc says "server-authoritative," but the platform relay has no per-game logic —
this matches cockpit-swarm's "host-auth, zero server changes" pattern. The
deterministic core exists so the host can run it with seeded dice and broadcast events.
For online, send commands (`{ type: "ATTACK", actorId, targetId }`), never rendered
positions; the host re-validates through the same `rules/` modules.

## Architecture

Two strictly separated state worlds, both owned by `game/GameController.js`:
- **`this.match`** — authoritative, serializable match state (from `core/`). Only the
  reducer mutates it; this is what an online host would broadcast.
- **`this.ui`** — throwaway local state: selected unit, action mode, legal-tile
  highlight set, animation lock. Never authoritative, never networked.

`view()` merges the two under the field names the renderers already expect, so the
SVG/HUD renderers stay untouched. Animations are driven from the reducer's returned
events, not from mutated state.

### Module map
```
src/
  config.js              ← balance values (UNIT_TYPES, MEDIC_HEAL_RANGE = 3, colors)
  main.js                ← boot: wire elements + controller, start()
  game/GameController.js  ← input → commands → reducer → animate events; owns match vs ui split
  core/                  ← deterministic, headless, DOM-free engine
    rng.js               ← seeded mulberry32 (replaces Math.random in authoritative play)
    roster.js            ← createRoster: playerCount/format/teams/colors → players[] (1-4)
    state.js             ← createMatchState (builds roster+turnOrder), clone/serialize, findUnit
    commands.js          ← command vocabulary + builders
    events.js            ← event vocabulary emitted by accepted commands
    errors.js            ← rejection codes
    reducer.js           ← applyCommand(state, cmd) → {accepted, nextState, events} | {accepted:false, errorCode}
    state-hash.js        ← FNV-1a stable hash for desync / replay checks
  geometry/isometric.js   ← grid↔screen projection, board bounds/viewBox, chebyshev, line trace
  state/gameState.js      ← initial unit placement + lookup helpers
  rules/                 ← renderer-independent movement / combat / turns (reused by reducer)
  render/                ← SVG generation + animation (board, unit, overlay, hud, effects, svg)
  ui/                    ← elements.js (DOM lookup), messageController.js
styles/                  ← tokens / layout / board / effects / responsive
```

## Rendering Notes (read before touching visuals)

- **viewBox is computed, not fixed.** `GameController.applyViewBox()` calls
  `createBoardViewBox(metrics, size)` (`geometry/isometric.js`) to wrap the viewBox
  tightly around the board's real pixel bounds (+ padding for rising float text,
  expanding rings, lobbed arcs). This is what makes the board fill the stage instead
  of floating tiny inside a fixed oversized canvas. The decorative `#boardGlow`
  ellipse is re-centered on the same bounds. If you change tile sizes or origin in
  `createBoardMetrics`, the viewBox follows automatically.
- **SVG transform-origin gotcha.** SVG elements default to `transform-origin: 0 0`
  at the *viewBox corner*. Any element positioned by `x`/`y` attributes that also
  animates `scale()` will drift diagonally across the board unless it sets
  `transform-box: fill-box; transform-origin: center` (see `.float-text` in
  `effects.css`). Units don't hit this because they're positioned by `transform:
  translate(...)` with geometry centered at local (0,0).
- **Float text appears over the target and rises** — it does not arc/travel from the
  attacker. The attacker→target arc is the separate projectile in
  `effectsRenderer.animateAttack` (ranger/medic only; warrior/tank lunge instead).
- **Render order / layers:** `#boardLayer` (tiles + move/target overlays) → `#overlayLayer`
  → `#unitsLayer` → `#fxLayer` (effects/float text). Units are depth-sorted by `x + y`.
- **Health-tone system.** `render/hp.js` `hpClass(hp, maxHp)` is the single source of truth
  for HP color thresholds (>50% high, >25% mid, else low), returning `hp-high`/`hp-mid`/
  `hp-low`. It's applied to every HP surface — board piece bars (`board.css`), the
  selected-unit card `.hpfill`, and the squad-chip mini bars (`layout.css`) — all driven
  by the `--hp-high/--hp-mid/--hp-low` tokens in `tokens.css`. Reuse it for any new HP UI.
- **Team identity in the HUD.** Current player shows as a colored dot on `.turn-title`
  (`[data-player]` in `layout.css`); squad chips carry a `p1`/`p2` top-border accent.
  Player colors are `--p1`/`--p2` tokens (mirrored by `PLAYER_COLORS` in `config.js`).

## Player Roster & Teams (core/roster.js, state/gameState.js, rules/turns.js)

Match state carries a **roster** so 2P duel / 3–4P free-for-all / 2v2 teams all
flow from one rule set. Decided in design with the user (2026-06-22):
- **Modes:** 2P duel, 3–4P FFA, 2v2 teams. **Boards:** 13×13 for 3–4P, 10×10 for 2P.
- **`state.players`** = `[{ id, team, corner, color }]`; **`state.turnOrder`** = seat
  sequence. Built by `createRoster({ playerCount, format, teams, colors })`. Defaults
  reproduce the classic duel exactly (roster `[1,2]`, turnOrder `[1,2]`).
- **Team is the single source of friend/foe.** `teamOf(state, player)` /
  `sameTeam(state, a, b)` (in `state/gameState.js`) replace every `player ===` check
  in `rules/combat.js` and `core/reducer.js`. FFA → each player is its own team, so
  the fallback (no roster) behaves identically to the old 2-player code. **Full
  allies:** teammates can't attack each other, medics heal teammates across player
  slots, and teammates block ranger LOS / movement (position-based, already team-agnostic).
- **Turns:** seat order, skipping eliminated players (`nextActivePlayer` in
  `rules/turns.js`). In 2v2, odd seats = team 1, even seats = team 2, so seat order
  naturally alternates teams while allies sit on opposite board diagonals.
- **Winner = last team standing** (`determineWinner` returns a *team* id; equals the
  player id in FFA). **Concede = drop-out:** the conceding player's units are removed
  and the match re-evaluates (a duel ends, a 4-player game plays on).
- **Color is data, never derived from slot.** Each roster entry owns its `color`
  (default = `PLAYER_COLORS[seat]`; slots 3/4 are green/orange). For teams, `createRoster`
  takes per-team hues (`teamColors`) and **shades** the second teammate darker (`shade()`
  in `roster.js`). Renderers read the roster color via `colorOf(state, player)`
  (`state/gameState.js`) and apply it through a **`--team` CSS custom property** set inline
  on each element — there are no `.p1/.p2`-by-slot color rules left; CSS derives shades with
  `color-mix`. Team/player naming + team color for victory text go through `render/labels.js`
  (`winnerLabel` / `teamColor`); `state.format` ("ffa"|"teams") drives "Team N" vs "Player N".
- **UI wiring:** the hot-seat **setup screen** (`ui/screens/hotSeatSetupScreen.js`) picks
  player count (2/3/4), format (Teams only at 4), per-team color swatches, and board size
  (forces 13×13 for 3–4P). It passes `{ playerCount, format, teamColors }` through
  `GameController.startMatch` → `matchConfig` → `createMatchState` (reused by restart/rematch).
  The HUD builds **one floating squad panel per player** into `#squadOverlays` (seat→screen
  corner: 1 BL, 2 BR, 3 TL, 4 TR).

## Starting Formation (state/gameState.js)

Each squad spawns as a **2×2 block in its corner**, generated per roster entry by
`createSquad`. The inner edge (facing board center) holds **tank + medic**; the outer
edge (the literal corner) holds **warrior + ranger**. Corner index → coordinates is
resolved by `cornerAnchors(size)`; index `0/1` reproduce the original P1/P2 placement
exactly, `2/3` are the remaining corners for players 3/4. (`max = size - 1`.)
- Corner 0 `(0, max)` — P1 (FFA) / team-1 seat. Corner 1 `(max, 0)` — P2.
- Corner 2 `(0, 0)`, Corner 3 `(max, max)` — players 3/4 (FFA) or the second diagonal (teams).

Spawn coordinates do not affect the logic tests — those build their own fixtures.

## Key Rules Encoded (see README for the full list)
- Warrior moves 3 (orthogonal); tank/ranger/medic move 2.
- Attack range includes diagonals, no penalty: warrior/tank 1, medic 3 (`MEDIC_HEAL_RANGE`),
  ranger 4. Ranger shots are blocked by intervening pieces.
- Dice: roll 1 misses, roll 6 crits (+1 damage; heal 4 instead of 3).
- Defend reduces each incoming hit by 1 (to zero), expires at the unit's next activation.
- Each living unit activates once per squad turn. Move-only activation is illegal —
  a move must be paired with attack/heal/defend. **Cancel Move** undoes an uncommitted
  move (returns to activation origin, stays selected/unspent) only before any primary
  action resolves.

## Files to Read First
New session: `game/GameController.js` (the match/ui split + flow), then
`core/reducer.js` (the single validator/mutator) and `core/state.js`. For visual work,
`render/` + `styles/` and the Rendering Notes above. For online, the scope doc §11.
