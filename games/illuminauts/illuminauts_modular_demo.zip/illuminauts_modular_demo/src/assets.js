export const SPRITE_SHEET_PATH = './assets/sprite-sheet.png';

// Manual atlas coordinates for assets/sprite-sheet.png.
// These are intentionally centralized so the renderer does not depend on sheet layout details.
export const sprites = {
  playerDown: { x: 105, y: 82, w: 126, h: 126 },
  playerUp: { x: 292, y: 82, w: 126, h: 126 },
  playerLeft: { x: 102, y: 262, w: 130, h: 140 },
  playerRight: { x: 298, y: 262, w: 130, h: 140 },

  alienPatrol: { x: 552, y: 72, w: 205, h: 205 },
  powerCell: { x: 818, y: 70, w: 150, h: 190 },
  accessChip: { x: 1020, y: 118, w: 255, h: 120 },

  turretUp: { x: 140, y: 440, w: 180, h: 190 },
  turretDown: { x: 480, y: 440, w: 180, h: 190 },
  turretLeft: { x: 735, y: 455, w: 230, h: 150 },
  turretRight: { x: 1050, y: 455, w: 230, h: 150 },

  laserDoorActive: { x: 165, y: 740, w: 370, h: 160 },
  laserDoorDisabled: { x: 590, y: 740, w: 290, h: 160 },

  beaconCore: { x: 965, y: 665, w: 330, h: 320 }
};

let spriteSheet = null;

export function loadAssets() {
  return new Promise((resolve, reject) => {
    const source = new Image();
    source.src = SPRITE_SHEET_PATH;
    source.onload = () => {
      spriteSheet = buildTransparentSheet(source);
      resolve();
    };
    source.onerror = () => reject(new Error(`[Illuminauts assets] Failed to load ${SPRITE_SHEET_PATH}`));
  });
}

// The prototype sheet generated for testing includes a checkerboard presentation background.
// This strips only high-value neutral checker pixels so the sprites can be tested in-game.
function buildTransparentSheet(source) {
  const canvas = document.createElement('canvas');
  canvas.width = source.width;
  canvas.height = source.height;

  const ctx = canvas.getContext('2d');
  ctx.drawImage(source, 0, 0);

  const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = image.data;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);

    if (min >= 228 && max - min <= 12) {
      data[i + 3] = 0;
    }
  }

  ctx.putImageData(image, 0, 0);
  return canvas;
}

export function getSpriteFrame(name) {
  return sprites[name] || null;
}

export function drawSprite(ctx, name, x, y, w, h) {
  const frame = getSpriteFrame(name);
  if (!spriteSheet || !frame) return false;

  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(
    spriteSheet,
    frame.x,
    frame.y,
    frame.w,
    frame.h,
    x,
    y,
    w,
    h
  );

  return true;
}

export function drawSpriteContain(ctx, name, cx, cy, maxW, maxH) {
  const frame = getSpriteFrame(name);
  if (!frame) return false;

  const scale = Math.min(maxW / frame.w, maxH / frame.h);
  const w = frame.w * scale;
  const h = frame.h * scale;
  return drawSprite(ctx, name, cx - w / 2, cy - h / 2, w, h);
}
